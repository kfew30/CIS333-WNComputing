import SettingsViewer from './SettingsViewer.vue'
import Title from './Title.vue'

export { SettingsViewer, Title }
