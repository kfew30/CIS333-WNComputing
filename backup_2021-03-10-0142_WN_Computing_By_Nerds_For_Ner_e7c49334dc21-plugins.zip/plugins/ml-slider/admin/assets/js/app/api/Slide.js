// import { Axios as api } from '../api'

const Slide = {
	// create() {
	// 	return api.get('images/all', {
	// 		params: { page: page, nocache: nocache }
	// 	})
	// },
	// save() {
	// 	return api.post('images/search', {
	// 		page: page,
	// 		search: search
	// 	})
	// }

	// delete() {
	// 	return api.post('images/search', {
	// 		page: page,
	// 		search: search
	// 	})
	// },
	// crop() {
	// 	return api.post('images/search', {
	// 		page: page,
	// 		search: search
	// 	})
	// }
}

export default Slide
